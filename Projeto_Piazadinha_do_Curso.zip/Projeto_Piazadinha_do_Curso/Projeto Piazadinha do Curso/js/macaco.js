<script>
 $(function(){
     $(".button-collapse").sideNav()
 });
</script>